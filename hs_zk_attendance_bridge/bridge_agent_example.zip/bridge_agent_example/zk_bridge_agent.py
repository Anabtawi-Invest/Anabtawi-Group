#!/usr/bin/env python3
"""Backward-compatible ZK entrypoint.

Prefer:
  SOURCE_TYPE=zk python3 agent.py

This wrapper keeps existing scripts working.
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

os.environ.setdefault("SOURCE_TYPE", "zk")

from agent import main

if __name__ == "__main__":
    raise SystemExit(main())
